import React from "react";

const sizes = {
  s: "text-3xl font-bold md:text-[28px] sm:text-[26px]",
  md: "text-[40px] font-bold md:text-[38px] sm:text-4xl",
  xs: "text-xl font-bold",
  lg: "text-[50px] font-bold md:text-[46px] sm:text-[40px]",
};

const HeadingContact = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-gray-600 font-inter ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingContact };
