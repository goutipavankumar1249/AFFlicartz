import React from "react";

const sizes = {
  xl: "text-[100px] font-extrabold md:text-5xl",
  s: "text-3xl font-semibold md:text-[28px] sm:text-[26px]",
  md: "text-[40px] font-extrabold md:text-[38px] sm:text-4xl",
  xs: "text-xl font-bold",
  lg: "text-6xl font-semibold md:text-[52px] sm:text-[46px]",
};

const HeadingHome = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-[#6f6f6f] font-['Inter'] ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingHome };
