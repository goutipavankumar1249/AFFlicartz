import React from "react";

const sizes = {
  xs: "text-xs font-normal",
  s: "text-sm font-normal",
  xl: "text-[32px] font-thin md:text-3xl sm:text-[28px]",
};

const TextLog = ({ children, className = "", as, size = "s", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-green-900 font-poppins ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { TextLog };
