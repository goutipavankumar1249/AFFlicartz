import React from "react";

const sizes = {
  s: "text-[50px] font-bold md:text-[46px] sm:text-[40px]",
  md: "text-[80px] font-extrabold md:text-5xl",
  xs: "text-5xl font-semibold md:text-[44px] sm:text-[38px]",
};

const HeadingOTP = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-gray-700 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingOTP };
