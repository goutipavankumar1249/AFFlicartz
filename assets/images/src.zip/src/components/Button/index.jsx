import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const shapes = {
  round: "rounded-[17px]",
  circle: "rounded-[50%]",
};
const variants = {
  fill: {
    white_A700: "bg-white-A700 text-green-900",
    blue_gray_100: "bg-blue_gray-100",
  },
};
const sizes = {
  xs: "h-[35px] px-[35px] text-lg",
  sm: "h-[36px] px-[3px]",
};

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape,
  variant = "fill",
  size = "sm",
  color = "",
  path="/",
  ...restProps
}) => {
  return (
    <>
      <Link to={path}>
        <button
          className={`${className} flex flex-row items-center justify-center text-center cursor-pointer ${(shape && shapes[shape]) || ""} ${(size && sizes[size]) || ""} ${(variant && variants[variant]?.[color]) || ""}`}
          {...restProps}
        >
          {!!leftIcon && leftIcon}
          {children}
          {!!rightIcon && rightIcon}
        </button>
      </Link>
    </>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
  shape: PropTypes.oneOf(["round", "circle"]),
  size: PropTypes.oneOf(["xs", "sm"]),
  variant: PropTypes.oneOf(["fill"]),
  color: PropTypes.oneOf(["white_A700", "blue_gray_100"]),
};

export { Button };
