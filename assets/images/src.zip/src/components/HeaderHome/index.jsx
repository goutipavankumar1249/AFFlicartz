import { Link } from "react-router-dom";
import { CloseSVG } from "../../assets/images";
import { ImgHome, HeadingHome, InputHome } from "./..";
import React from "react";

export default function HeaderHome({ ...props }) {
  const [searchBarValue, setSearchBarValue] = React.useState("");

  return (
    <header
      {...props}
      className={`${props.className} flex justify-center items-center w-[93%] md:w-full p-[9px] white_A700_99_white_A700_99_border bg-gradient-to-b from-[#ffffff66] to-[#ffffff19] shadow-[0px_20px_40px_0px_#0000003f] rounded-[24px]`}
    >
      <div className="mx-auto flex w-full max-w-[1287px] items-center justify-start gap-10 md:flex-col">
        <div className="flex w-[15%] items-center justify-between gap-5 md:w-full">
          <ImgHome src="images/img_image_1.png" alt="header logo" className="h-[50px] w-[50px] object-contain" />
          <HeadingHome as="h5" className="!text-[#000000]">
            <span className="text-[#105c0a]">A</span>
            <span className="text-[#000000]">fflicart</span>
            <span className="text-[#105c0a]">Z</span>
          </HeadingHome>
        </div>
        <InputHome
          name="Search Field"
          placeholder={`Search`}
          value={searchBarValue}
          onChange={(e) => setSearchBarValue(e)}
          prefix={<ImgHome src="images/img_search.svg" alt="search" className="h-[18px] w-[18px] cursor-pointer" />}
          suffix={
            searchBarValue?.length > 0 ? (
              <CloseSVG onClick={() => setSearchBarValue("")} height={18} width={18} fillColor="#6f6f6fff" />
            ) : null
          }
          className="flex h-[42px] w-[26%] items-center justify-center gap-[17px] rounded-[21px] bg-[#d9d9d9] pl-2.5 pr-[35px] font-['Inter'] text-lg text-[#6f6f6f] md:w-full sm:pr-5"
        />
        <ul className="flex flex-row flex-wrap justify-start gap-5">
          <li>
            <Link to="/">
              <HeadingHome as="h5">Home</HeadingHome>
            </Link>
          </li>
          <li>
            <Link to="/earnings">
              <HeadingHome as="h5">Earnings</HeadingHome>
            </Link>
          </li>
          <li>
            <Link to="/profile">
              <HeadingHome as="h5">Profile</HeadingHome>
            </Link>
          </li>
          <li>
            <Link to="/stores">
              <HeadingHome as="h5">Store</HeadingHome>
            </Link>
          </li>
          <li>
            <Link to="/aboutus">
              <HeadingHome as="h5">About Us</HeadingHome>
            </Link>
          </li>
          <li>
            <Link to="/contactus">
              <HeadingHome as="h5">Contact Us</HeadingHome>
            </Link>
          </li>
        </ul>
        <a href="#">
          <ImgHome
            src="images/img_image_2.png"
            alt="promotional image"
            className="h-[50px] w-[50px] rounded-[25px] object-cover md:w-full"
          />
        </a>
      </div>
    </header>
  );
}
