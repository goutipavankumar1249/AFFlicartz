import { HeadingPage, Img } from "./..";
import React from "react";

export default function EarningsColumnOne({ afflicartz, description, ...props }) {
  return (
    <div
      {...props}
      className={`${props.className} w-[82%] h-max left-[0.00px] bottom-0 top-0  md:pb-5 absolute`}
    >
      <div className="relative h-[1024px] self-stretch md:h-auto md:hidden">
        <Img src="images/img_rectangle_97.png" alt="profileimage" className="h-[1024px] w-[61%] object-cover" />
        <div className="absolute bottom-0 left-0 right-0 top-0 mx-auto mb-auto flex h-[1024px] w-full items-center bg-[url(/public/images/img_group_5.png)] bg-cover bg-no-repeat px-7 pb-[142px] md:h-auto md:py-5 sm:p-5">
          <div className="mt-[100px] flex w-[59%] flex-col items-end gap-[49px] md:w-full">
            <div className="mr-24 w-[77%] md:mr-0 md:w-full">
              <div className="flex flex-col gap-[31px]">
                <div className="flex items-center justify-between gap-5">
                  <Img src="images/img_image_1.png" alt="afflicartzlogo" className="h-[116px] w-[116px] object-cover" />
                  <HeadingPage size="xl" as="h1" className="!font-inter !text-black-900">
                    <span className="text-green-900">A</span>
                    <span className="text-black-900">fflicart</span>
                    <span className="text-green-900">Z</span>
                  </HeadingPage>
                </div>
                <Img src="images/img_wallet_bro.svg" alt="walletimage" className="h-[357px] w-[86%]" />
              </div>
            </div>
            <HeadingPage size="md" as="h3" className="w-full text-center leading-9 tracking-[0.60px]">
              <span className="text-green-900">Welcome to your A</span>
              <span className="text-black-900">
                fflicartz Cashback App Earning Page! Track your total cashback, view recent transactions, and manage
                withdrawals. Maximize your rewards with exclusive promotions.
              </span>
            </HeadingPage>
          </div>
        </div>
      </div>
    </div>
  );
}
