import { ImgOTP, TextOTP, HeadingOTP } from "./..";
import React from "react";

export default function OTPStackview({
  afflicartz,
  earncashback = "Earn Cashback",
  onevery = "on Every Purchase",
  shopatyour,
  ...props
}) {
  return (
    <div
      {...props}
      className={`${props.className} h-[1345px] w-[90%] md:h-auto pb-[321px] left-[0.00px] bottom-0 top-0 my-auto md:pb-5 absolute`}
    >
      <div className="h-[1024px] w-[61%] bg-light_green-200" />
      <div className="absolute bottom-0 left-0 right-0 top-0 m-auto h-[1024px] w-full bg-[url(/public/images/img_group_1.png)] bg-cover bg-no-repeat pb-[100px] pr-[282px] pt-[71px] md:py-5 md:pr-5">
        <div className="absolute right-[24%] top-[7%] m-auto flex w-[94%] flex-col">
          <ImgOTP
            src="images/img_image_1.png"
            alt="heroimage"
            className="ml-[280px] h-[116px] w-[116px] object-cover md:ml-0"
          />
          <div className="relative mt-[-89px] flex flex-col items-center gap-[27px]">
            <HeadingOTP size="s" as="h1" className="!font-inter !text-black-900">
              <span className="text-green-900">A</span>
              <span className="text-black-900">fflicart</span>
              <span className="text-green-900">Z</span>
            </HeadingOTP>
            <div className="self-stretch pb-3.5">
              <div className="ml-[250px] mt-[-20px] flex flex-col items-start justify-start gap-[39px]">
                <div className="flex flex-col items-start gap-[3px]">
                  <HeadingOTP size="md" as="h1" className="italic !text-green-900">
                    {earncashback}
                  </HeadingOTP>
                  <HeadingOTP as="h1" className="italic">
                    {onevery}
                  </HeadingOTP>
                </div>
                <TextOTP as="p" className="italic">
                  <span className="font-shrikhand font-normal text-green-900">“</span>
                  <span className="text-green-900">Shop at your favorite stores and get money back!</span>
                  <span className="font-shrikhand font-normal text-green-900">“</span>
                </TextOTP>
              </div>
            </div>
          </div>
        </div>
        <ImgOTP
          src="images/img_image_removebg_preview.png"
          alt="backgroundimage"
          className="absolute bottom-[10%] left-[0.00px] m-auto h-[514px] w-[62%] object-cover"
        />
        <ImgOTP
          src="images/img_image_removebg_preview_514x530.png"
          alt="foregroundimage"
          className="absolute bottom-[13%] left-[0.00px] m-auto h-[514px] w-[59%] object-cover"
        />
      </div>
    </div>
  );
}
