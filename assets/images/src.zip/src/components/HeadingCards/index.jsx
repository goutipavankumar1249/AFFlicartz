import React from "react";

const sizes = {
  s: "text-[40px] font-semibold md:text-[38px] sm:text-4xl",
  xs: "text-xl font-semibold",
};

const HeadingCards = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-white-A700 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingCards };
