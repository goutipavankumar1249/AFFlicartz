import React from "react";

const sizes = {
  xl: "text-[50px] font-bold md:text-4xl sm:text-3xl",
  s: "text-xl font-bold",
  md: "text-3xl font-bold md:text-[24px] sm:text-[18px]",
  xs: "text-xs font-bold",
  lg: "text-[40px] font-bold md:text-[38px] sm:text-4xl",
};

const HeadingPage = ({ children, className = "", size = "s", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-green-900 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingPage };
