import React from "react";

const sizes = {
  xl: "text-[80px] font-extrabold md:text-5xl",
  s: "text-xl font-bold",
  md: "text-5xl font-semibold md:text-[44px] sm:text-[38px]",
  xs: "text-xs font-bold",
  lg: "text-[50px] font-bold md:text-[46px] sm:text-[40px]",
};

const Heading = ({ children, className = "", size = "md", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-green-900 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Heading };
