import React from "react";

const sizes = {
  xs: "text-[32px] font-thin md:text-3xl sm:text-[28px]",
};

const TextOTP = ({ children, className = "", as, size = "xs", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-green-900 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { TextOTP };
