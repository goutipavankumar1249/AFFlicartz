import { ImgHome, HeadingHome } from "./..";
import React from "react";

export default function Desktop1Stacksignup({
  title = "Shop",
  description1 = "Shop at your favorite stores through our platform.",
  description2 = " Browse our partnered stores, click through our links, and shop as usual to earn cashback.",
  image = "images/img_character_1.svg",
  ...props
}) {
  return (
    <div {...props} className={`${props.className} relative`}>
      <div className="absolute bottom-0 left-[0.00px] top-0 my-auto flex h-max w-[70%] flex-col items-center gap-[18px]">
        <HeadingHome size="md" as="h1" className="block italic !text-[#5c5c5c]">
          {title}
        </HeadingHome>
        <div className="white_A700_99_white_A700_99_border flex flex-col items-center gap-[30px] self-stretch rounded-[24px] bg-gradient-to-b from-[#ffffff66] to-[#ffffff19] px-[15px] pb-2.5 pt-[35px] shadow-[0px_20px_40px_0px_#0000003f] sm:pt-5">
          <HeadingHome size="s" as="h3" className="w-[98%] text-center italic leading-[35px] !text-[#105c0a] md:w-full">
            {description1}
          </HeadingHome>
          <HeadingHome as="h5" className="w-full text-center !font-semibold italic leading-[23px] !text-[#7c8576]">
            {description2}
          </HeadingHome>
        </div>
      </div>
      <ImgHome
        src={image}
        alt="promo image"
        className="absolute bottom-[0.00px] right-[-0.16px] m-auto h-[311px] w-[41%]"
      />
    </div>
  );
}
