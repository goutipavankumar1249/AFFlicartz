import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const ButtonHome = ({
  children,
  className = "",
  leftIcon,
  rightIcon,

  ...restProps
}) => {
  return (
    <Link to='/signup'>
      <button className={`${className} `} {...restProps}>
        {!!leftIcon && leftIcon}
        {children}
        {!!rightIcon && rightIcon}
      </button>
    </Link>
  );
};

ButtonHome.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
};

export { ButtonHome };
