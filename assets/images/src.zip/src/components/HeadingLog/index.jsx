import React from "react";

const sizes = {
  "3xl": "text-[80px] font-extrabold md:text-5xl",
  "2xl": "text-[50px] font-bold md:text-[46px] sm:text-[40px]",
  xl: "text-5xl font-semibold md:text-[44px] sm:text-[38px]",
  s: "text-xl font-bold",
  xs: "text-xs font-bold",
};

const HeadingLog = ({ children, className = "", size = "xl", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-green-900 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingLog };
