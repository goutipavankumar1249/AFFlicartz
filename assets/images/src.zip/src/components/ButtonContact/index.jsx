import React from "react";
import PropTypes from "prop-types";

const ButtonContact = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  ...restProps
}) => {
  return (
    <>
        <button className={`${className} `} {...restProps}>
          {!!leftIcon && leftIcon}
          {children}
          {!!rightIcon && rightIcon}
        </button>
    </>
  );
};

ButtonContact.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
};

export { ButtonContact };
