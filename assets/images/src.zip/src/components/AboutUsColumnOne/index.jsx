import { HeadingAbout, TextAbout, ImgAbout } from "./..";
import React from "react";

export default function AboutUsColumnOne({
  afflicartz,
  welcometo,
  studentfocused = "Student-Focused",
  transparency = "Transparency",
  datasecurity = "Data Security",
  ...props
}) {
  return (
    <div
      {...props}
      className={`${props.className} w-[82%] h-auto pb-[10px] left-[0.00px] bottom-0 top-0 md:pb-5 absolute overscroll-x-contain`}
    >
      <div className="relative min-h-screen h-[1020px] top-0 md:h-auto overflow-x-hidden">
        <ImgAbout src="images/img_rectangle_97.png" alt="profileimage" className="h-full pt-[10px] w-[62%] object-cover" />
        <div className="absolute bottom-0 left-0 right-0 top-0 m-auto flex h-[1024px] w-full items-center bg-[url(/public/images/img_group_1.png)] bg-cover bg-no-repeat px-7 pb-[72px] md:h-auto md:py-5 sm:p-5">
          <div className="w-[61%] md:w-full">
            <div className="flex flex-col">
              <div className="relative ml-[25px] h-[540px] w-[88%] md:ml-0 md:h-auto">
                <div className="flex w-full flex-col items-start">
                  <ImgAbout
                    src="images/img_image_1.png"
                    alt="firstimage"
                    className="ml-[109px] h-[116px] w-[116px] object-cover md:ml-0"
                  />
                  <ImgAbout
                    src="images/img_about_us_page_bro.svg"
                    alt="secondimage"
                    className="relative mt-[-13px] h-[437px] w-full md:h-auto"
                  />
                </div>
                <HeadingAbout size="lg" as="h1" className="absolute right-[6%] top-[26.55px] m-auto !text-[#000000]">
                  <span className="text-[#105c0a]">A</span>
                  <span className="text-[#000000]">fflicart</span>
                  <span className="text-[#105c0a]">Z</span>
                </HeadingAbout>
              </div>
              <TextAbout
                size="s"
                as="p"
                className="mt-3.5 w-[98%] text-center leading-9 tracking-[0.60px] !text-[#000000] md:w-full"
              >
                <span className="text-[#105c0a]">Welcome to A</span>
                <span className="text-[#000000]">fflicart</span>
                <span className="text-[#105c0a]">
                  Z, your go-to destination for exclusive cashback offers on your favorite online purchases.
                </span>
              </TextAbout>
              <div className="mt-[142px] flex items-start gap-[18px] md:flex-col">
                <HeadingAbout size="s" as="h3" className="tracking-[0.56px]">
                  {studentfocused}
                </HeadingAbout>
                <div className="mt-3.5 h-[5px] w-[5px] rounded-sm bg-[#105c0a]" />
                <HeadingAbout size="s" as="h3" className="tracking-[0.56px]">
                  {transparency}
                </HeadingAbout>
                <div className="mt-3.5 h-[5px] w-[5px] rounded-sm bg-[#105c0a]" />
                <HeadingAbout size="s" as="h3" className="tracking-[0.56px]">
                  {datasecurity}
                </HeadingAbout>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
