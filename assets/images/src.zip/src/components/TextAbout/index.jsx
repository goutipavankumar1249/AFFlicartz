import React from "react";

const sizes = {
  xs: "text-xl font-normal",
  s: "text-3xl font-medium md:text-[28px] sm:text-[26px]",
};

const TextAbout = ({ children, className = "", as, size = "xs", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-[#ffffff] font-['SF_Pro_Display'] ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { TextAbout };
