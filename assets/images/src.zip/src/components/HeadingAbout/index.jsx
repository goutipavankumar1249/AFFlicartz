import React from "react";

const sizes = {
  s: "text-[22px] font-bold md:text-[18px] sm:text-2xl",
  md: "text-[30px] font-bold md:text-[25px] sm:text-4xl",
  xs: "text-xl font-bold",
  lg: "text-[40px] font-bold md:text-[35px] sm:text-[25px]",
};

const HeadingAbout = ({ children, className = "", size = "xs", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-[#105c0a] font-['Inter'] ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { HeadingAbout };
