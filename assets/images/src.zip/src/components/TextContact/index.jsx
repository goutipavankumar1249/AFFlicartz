import React from "react";

const sizes = {
  xs: "text-xl font-medium",
};

const TextContact = ({ children, className = "", as, size = "xs", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-white-A700 font-sfprodisplay ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { TextContact };
