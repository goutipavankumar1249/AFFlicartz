import React from "react";

const sizes = {
  xs: "text-[40px] font-thin md:text-[38px] sm:text-4xl",
};

const TextHome = ({ children, className = "", as, size = "xs", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-[#105c0a] font-['SF_Pro_Display'] ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { TextHome };
