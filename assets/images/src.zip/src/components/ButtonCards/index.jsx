import React from "react";
import PropTypes from "prop-types";

const shapes = {
  round: "rounded-[16px]",
};
const variants = {
  fill: {
    green_900: "bg-green-900 shadow-xs text-white-A700",
  },
};
const sizes = {
  xs: "h-[44px] px-[15px] text-xl",
};

const ButtonCards = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape,
  variant = "fill",
  size = "md",
  color = "green_900",
  ...restProps
}) => {
  return (
    <button
      className={`${className} flex flex-row items-center justify-center text-center cursor-pointer text-white-A700 text-[20px] font-normal bg-green-900 shadow-xs italic  md:text-[15px] ${(shape && shapes[shape]) || ""} ${(size && sizes[size]) || ""} ${(variant && variants[variant]?.[color]) || ""}`}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

ButtonCards.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
  shape: PropTypes.oneOf(["round"]),
  size: PropTypes.oneOf(["xs"]),
  variant: PropTypes.oneOf(["fill"]),
  color: PropTypes.oneOf(["green_900"]),
};

export { ButtonCards };
