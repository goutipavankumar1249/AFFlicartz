import React from "react";
import { useRoutes } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
import SignUp from "pages/SignUp";
import LogIn from "pages/LogIn";
import ForgetPassword from "pages/ForgetPassword";
import OTP from "pages/OTP";
import AboutUs from "pages/AboutUs";
import ContactUs from "pages/ContactUs";
import FeaturedStores from "pages/FeaturedStores";
import Earnings from "pages/Earnings";
import Profile from "pages/Profile";
import BankDetails from "pages/BankDetails";
import Orders from "pages/Orders";
import OrderDetails from "pages/OrderDetails";
import AllStores from "pages/AllStores";


const ProjectRoutes = () => {
  let element = useRoutes([
    { path: "/", element: <Home /> },
    { path: "*", element: <NotFound /> },
    {
      path: "signup",
      element: <SignUp />,
    },
    {
      path: "login",
      element: <LogIn />,
    },
    {
      path: "forgetpassword",
      element: <ForgetPassword />,
    },
    {
      path: "otp",
      element: <OTP />,
    },
    {
      path: "aboutus",
      element: <AboutUs />,
    },
    {
      path: "contactus",
      element: <ContactUs />,
    },
    {
      path: "stores",
      element: <FeaturedStores />,
    },
    {
      path: "earnings",
      element: <Earnings />,
    },
    {
      path: "profile",
      element: <Profile />,
    },
    {
      path: "bankdetails",
      element: <BankDetails />,
    },
    {
      path: "orders",
      element: <Orders />,
    },
    {
      path: "orders/:id",
      element: <OrderDetails />,
    },
    {
      path: "allstores",
      element: <AllStores />,
    },
  ]);

  return element;
};

export default ProjectRoutes;
