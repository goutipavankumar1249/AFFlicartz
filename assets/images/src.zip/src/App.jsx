import React from "react";
import { BrowserRouter as Router, useLocation } from "react-router-dom";
import Routes from "./Routes";
import HeaderHome from "components/HeaderHome";

const Main = () => {
  const location = useLocation();
  const noHeaderPaths = ["/signup", "/login", "/otp", "/forgetpassword"];

  return (
    <>
      {/* {!noHeaderPaths.includes(location.pathname) && (
        <div className="flex items-center pt-[10px] justify-center bg-gradient-to-b from-[#A8C879] to-[#A8C879]">
          <HeaderHome />
        </div>
      )} */}
      <Routes />
    </>
  );
};

function App() {
  return (
    <Router>
      <Main />
    </Router>
  );
}

export default App;
