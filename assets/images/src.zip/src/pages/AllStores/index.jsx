import { useEffect, useState } from "react";
import { Helmet } from "react-helmet";
import { HeadingCards, Img, ButtonCards } from "../../components";

const sampleData = {
    "stores": [
        {
            "id": 1,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.amazon.in&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/341759/amazon-.in-logo-400-x-200.png",
            "merchant": "Amazon India",
            "category": "Automobiles,Baby & Kids,Books,Electronics,Fashion,Food & Grocery,Gifting & Toys,Health & Beauty,Home & Kitchen,Jewelery,Pets,Sports & Fitness,Others",
            "type": "cps",
            "payout": "12%",
            "status": "active"
        },
        {
            "id": 8,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.agoda.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/341763/agoda-logo-400-x-200.png",
            "merchant": "Agoda",
            "category": "Travel",
            "type": "cps",
            "payout": "4%",
            "status": "active"
        },
        {
            "id": 10,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.ajio.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/418611/Ajio_400x200_logo-png.png",
            "merchant": "Ajio",
            "category": "Fashion",
            "type": "cps",
            "payout": "10.8%",
            "status": "active"
        },
        {
            "id": 13,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpl&url=https%3A%2F%2Fwww.americanexpress.com%2Fin%2Fcredit-cards%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/67/41b51cdb-d1b4-43bb-8345-7857f2c7abe1.png",
            "merchant": "Amex Credit Card",
            "category": "Others",
            "type": "cpl",
            "payout": "₹2800",
            "status": "active"
        },
        {
            "id": 17,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.archiesonline.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/91088/yN6zwVJfvHWXCAAAAAElFTkSuQmCC",
            "merchant": "Archies",
            "category": "Gifting & Toys",
            "type": "cps",
            "payout": "7%",
            "status": "inactive"
        },
        {
            "id": 24,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.biba.in&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/341644/biba--logo-400-x-200.png",
            "merchant": "Biba",
            "category": "Fashion",
            "type": "cps",
            "payout": "13.5%",
            "status": "active"
        },
        {
            "id": 33,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.cleartrip.com%2Fflights&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/393913/cleartrip-logo.png",
            "merchant": "Cleartrip",
            "category": "Travel",
            "type": "cps",
            "payout": "₹270",
            "status": "active"
        },
        {
            "id": 2967,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Ftego.fit%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/477837/tego_logo.png",
            "merchant": "Tegofit",
            "category": "Fashion,Sports & Fitness",
            "type": "cps",
            "payout": "15%",
            "status": "inactive"
        },
        {
            "id": 2968,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fprotouchskin.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/479325/protouch_logo.png",
            "merchant": "Protouch",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "17%",
            "status": "active"
        },
        {
            "id": 2969,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.adilqadri.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/479378/Adilqadri_logo.png",
            "merchant": "Adil Qadri",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "17%",
            "status": "inactive"
        },
        {
            "id": 2970,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.watchstationindia.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/479965/watch-station_logo.png",
            "merchant": "Watchstation",
            "category": "Fashion",
            "type": "cps",
            "payout": "18%",
            "status": "active"
        },
        {
            "id": 2973,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpr&url=https%3A%2F%2Fwww.adanione.com%2Flogin&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/480823/Adani-One-Alpha-Gradient.png",
            "merchant": "Adani CPR",
            "category": "Travel",
            "type": "cpr",
            "payout": "₹3.2",
            "status": "inactive"
        },
        {
            "id": 2974,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fworldofasaya.com%2Fcollections%2Fall-products&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/481088/Asaya_LOGO.png",
            "merchant": "Asaya",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "97%",
            "status": "active"
        },
        {
            "id": 2975,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fthebearhouse.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/481097/bearhouseindia_logo.png",
            "merchant": "BearHouse",
            "category": "Fashion",
            "type": "cps",
            "payout": "13.5%",
            "status": "active"
        },
        {
            "id": 2976,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.aksclothings.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/481350/global.aksclothings_logo.png",
            "merchant": "Aks Clothing",
            "category": "Fashion",
            "type": "cps",
            "payout": "15%",
            "status": "active"
        },
        {
            "id": 2978,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.carinfo.app%2Fservice-history&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/481400/carinfo-logo.png",
            "merchant": "CarInfo",
            "category": "Automobiles",
            "type": "cps",
            "payout": "100",
            "status": "active"
        },
        {
            "id": 2980,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fappsumo.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/481861/APP-SUMO_Logo-%281%29.png",
            "merchant": "AppSumo",
            "category": "Online Services",
            "type": "cps",
            "payout": "80%",
            "status": "active"
        },
        {
            "id": 2981,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpr&url=https%3A%2F%2Fmudrex.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/482875/mudrex_logo.png",
            "merchant": "Mudrex App",
            "category": "Banking & Finance",
            "type": "cpr",
            "payout": "₹50",
            "status": "inactive"
        },
        {
            "id": 2982,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fflexxo.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/483317/Flexxo_logo-%281%29.png",
            "merchant": "Flexxo",
            "category": "Fashion",
            "type": "cps",
            "payout": "30%",
            "status": "inactive"
        },
        {
            "id": 2983,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fshopzlade.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/483347/ZLADE_Logo.png",
            "merchant": "Zlade",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "13.5%",
            "status": "active"
        },
        {
            "id": 2984,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpr&url=https%3A%2F%2Fsixer.dream11.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/484201/th.png",
            "merchant": "Sixer ",
            "category": "Gaming",
            "type": "cpr",
            "payout": "₹40",
            "status": "inactive"
        },
        {
            "id": 2985,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.shopyvision.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/484240/Shopy-Vision_logo.png",
            "merchant": "Shopy Vision",
            "category": "Electronics,Home & Kitchen",
            "type": "cps",
            "payout": "7.65%",
            "status": "active"
        },
        {
            "id": 2986,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fgoodveda.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/484379/goodveda_logo.png",
            "merchant": "Goodveda",
            "category": "Medical & Healthcare",
            "type": "cps",
            "payout": "29.75%",
            "status": "inactive"
        },
        {
            "id": 2987,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fzaverishop.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/484404/Zaveri-Shop_LOGO.png",
            "merchant": "Zaveri",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "25%",
            "status": "active"
        },
        {
            "id": 2988,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.myflighttrip.com%2Fflight-coupon.php&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/485255/MyFlightTrip_logo.png",
            "merchant": "MyFlight Trip",
            "category": "Travel",
            "type": "cps",
            "payout": "₹220",
            "status": "active"
        },
        {
            "id": 2989,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.masterclassspace.com%2Fbitsat.php&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/486796/Masterclass-space-BITSAT-logo.png",
            "merchant": "Masterclass space BITSAT",
            "category": "Education",
            "type": "cps",
            "payout": "50%",
            "status": "active"
        },
        {
            "id": 2990,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.theblackboxco.com%2Fcollections%2Ftravel&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/485681/the-black-box_logo.png",
            "merchant": "Black Box",
            "category": "Fashion",
            "type": "cps",
            "payout": "22%",
            "status": "active"
        },
        {
            "id": 2991,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpl&url=https%3A%2F%2Fyesrapido.yesbank.in%2Fsdcss%2Fd%2Fretail-banking%2Faccount-opening%2Fsavings&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/488619/images.png",
            "merchant": "Yes Bank Saving",
            "category": "Banking & Finance",
            "type": "cpl",
            "payout": "₹300",
            "status": "active"
        },
        {
            "id": 2992,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.godrejinterio.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/489129/interio_logo.png",
            "merchant": "Godrej Interio",
            "category": "Home & Kitchen",
            "type": "cps",
            "payout": "3.5%",
            "status": "active"
        },
        {
            "id": 2993,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa_cb&url=https%3A%2F%2Fwww.sbicard.com&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/490715/sbi-card-logo.png",
            "merchant": "SBI Cashback",
            "category": "Banking & Finance",
            "type": "cpa_cb",
            "payout": "₹2300",
            "status": "active"
        },
        {
            "id": 2994,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fshop.guarented.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/490951/guarented_logo.png",
            "merchant": "Guarented Sale",
            "category": "Home & Kitchen",
            "type": "cps",
            "payout": "₹280",
            "status": "active"
        },
        {
            "id": 2995,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fbaccabucci.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/491238/Bacca-Bucci-logo.png",
            "merchant": "Bacca Bucci",
            "category": "Fashion",
            "type": "cps",
            "payout": "8.5%",
            "status": "active"
        },
        {
            "id": 2996,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.watchoutwearables.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492072/watchout_logo.png",
            "merchant": "Watchout Wearables",
            "category": "Fashion",
            "type": "cps",
            "payout": "12%",
            "status": "active"
        },
        {
            "id": 2997,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Forgatre.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492074/orgatre_logo.png",
            "merchant": "Orgatre",
            "category": "Fashion",
            "type": "cps",
            "payout": "65%",
            "status": "inactive"
        },
        {
            "id": 2998,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.vegnonveg.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492252/vegnonveg_logo.png",
            "merchant": "VegNonVeg",
            "category": "Fashion",
            "type": "cps",
            "payout": "4.90%",
            "status": "inactive"
        },
        {
            "id": 2999,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.feedsmart.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492279/Untitled-design-%2867%29.png",
            "merchant": "FeedSmart",
            "category": "Food & Grocery",
            "type": "cps",
            "payout": "18.7%",
            "status": "active"
        },
        {
            "id": 3000,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps_bus&url=https%3A%2F%2Fwww.goibibo.com%2Fbus%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492851/goibibo-logo-400x200.png-2.png",
            "merchant": "Goibibo (Bus)",
            "category": "Travel",
            "type": "cps_bus",
            "payout": "₹35",
            "status": "active"
        },
        {
            "id": 3001,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fquillbot.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/492915/Untitled-design-%2871%29.png",
            "merchant": "Quillbot",
            "category": "Others",
            "type": "cps",
            "payout": "17.5%",
            "status": "active"
        },
        {
            "id": 3002,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa_cc&url=https%3A%2F%2Fapplyonline.hdfcbank.com&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/494322/hdfc_bank.png",
            "merchant": "Hdfc CC",
            "category": "Banking & Finance",
            "type": "cpa_cc",
            "payout": "₹2300",
            "status": "active"
        },
        {
            "id": 3003,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fshop.wildlypure.co%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/494866/Untitled-design-%2876%29.png",
            "merchant": "Wildly Pure",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "15%",
            "status": "active"
        },
        {
            "id": 3004,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fmokobara.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/494868/Untitled-design-%2877%29.png",
            "merchant": "Mokobara",
            "category": "Fashion",
            "type": "cps",
            "payout": "8.5%",
            "status": "active"
        },
        {
            "id": 3006,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fcellecor.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/494992/Untitled-design-%2879%29.png",
            "merchant": "Cellecor",
            "category": "Electronics",
            "type": "cps",
            "payout": "8.5%",
            "status": "active"
        },
        {
            "id": 3008,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fnyumi.com%2Fcollections%2Fall&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/496857/nyumi_logo.png",
            "merchant": "Nyumi",
            "category": "Food & Grocery",
            "type": "cps",
            "payout": "25%",
            "status": "active"
        },
        {
            "id": 3009,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fpunjabiadda.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/497453/Punjabi-Adda-logo.png",
            "merchant": "Punjabi Adda",
            "category": "Fashion",
            "type": "cps",
            "payout": "18.90%",
            "status": "active"
        },
        {
            "id": 3011,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fbeardo.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/497670/beardo--400x200-png.png",
            "merchant": "Beardo",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "18%",
            "status": "active"
        },
        {
            "id": 3012,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.nurepublic.co%2Fcollections%2Fall-products&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/499212/Nu-Republic_logo.png",
            "merchant": "NuRepublic",
            "category": "Electronics",
            "type": "cps",
            "payout": "14.5%",
            "status": "active"
        },
        {
            "id": 3013,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Ficon.in%2Fcollections%2Fshop-all&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/499433/icon_logo.png",
            "merchant": "Icon",
            "category": "Fashion",
            "type": "cps",
            "payout": "15%",
            "status": "active"
        },
        {
            "id": 3014,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.fixderma.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/499447/Fixderma-Skincare-_logo.png",
            "merchant": "Fixderma",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "13.5%",
            "status": "active"
        },
        {
            "id": 3015,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fcontrolz.world%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/499662/controlZ_logo.png",
            "merchant": "Controlz",
            "category": "Electronics",
            "type": "cps",
            "payout": "₹350",
            "status": "active"
        },
        {
            "id": 3016,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.superkicks.in%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500002/super-kicks_logo.png",
            "merchant": "Superkicks",
            "category": "Fashion",
            "type": "cps",
            "payout": "2.10%",
            "status": "inactive"
        },
        {
            "id": 3017,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fhomehygiene.co%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500327/home-hygiene.co-_logo.png",
            "merchant": "Home Hygiene",
            "category": "Home & Kitchen",
            "type": "cps",
            "payout": "50%",
            "status": "active"
        },
        {
            "id": 3018,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa&url=https%3A%2F%2Fdigital.idfcfirstbank.com%2Fapply%2Fsavings&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500333/images.jpeg",
            "merchant": "IDFC SA",
            "category": "Banking & Finance",
            "type": "cpa",
            "payout": "₹600",
            "status": "active"
        },
        {
            "id": 3019,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpi&url=https%3A%2F%2Fwww.goibibo.com&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500514/goibibo-logo-400x200.png-2.png",
            "merchant": "Goibibo App",
            "category": "Travel",
            "type": "cpi",
            "payout": "₹24",
            "status": "inactive"
        },
        {
            "id": 3020,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fwww.viagogo.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500679/viagogo-logo.png",
            "merchant": "Viagogo",
            "category": "Entertainment",
            "type": "cps",
            "payout": "5.95%",
            "status": "active"
        },
        {
            "id": 3021,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa&url=https%3A%2F%2Findie.indusind.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/500698/d.png",
            "merchant": "Indie By Indusind Bank App",
            "category": "Banking & Finance",
            "type": "cpa",
            "payout": "₹550",
            "status": "inactive"
        },
        {
            "id": 3023,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa&url=https%3A%2F%2Fwww.tide.co%2Fen-IN%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/501266/images.png",
            "merchant": "Tide App",
            "category": "Online Services",
            "type": "cpa",
            "payout": "₹900",
            "status": "inactive"
        },
        {
            "id": 3025,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fsoulandpeace.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/501270/soul-%26-peace-logo.png",
            "merchant": "Soul and Peace",
            "category": "Fashion",
            "type": "cps",
            "payout": "17.6%",
            "status": "active"
        },
        {
            "id": 3026,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa_fund&url=https%3A%2F%2Fleap.axisbank.com%2Fverification&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/501275/axis.png",
            "merchant": "Axis Amaze",
            "category": "Banking & Finance",
            "type": "cpa_fund",
            "payout": "₹600",
            "status": "active"
        },
        {
            "id": 3027,
            "url": "https://inr.deals/track?src=stores-api&campaign=cps&url=https%3A%2F%2Fdenverformen.com%2F&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/501277/Denverformen-_logo.png",
            "merchant": "Denver",
            "category": "Health & Beauty",
            "type": "cps",
            "payout": "18%",
            "status": "active"
        },
        {
            "id": 3029,
            "url": "https://inr.deals/track?src=stores-api&campaign=cpa&url=https%3A%2F%2Fwww.accountopening.hsbc.co.in%2Fcredit-cards%2F%23%21%2Fapp%2Fjourney%2Fcontact-details-VPC&id=esa574569153&subid=",
            "logo": "https://inrdeals.sgp1.cdn.digitaloceanspaces.com/production/501285/HSBC-Logo.png",
            "merchant": "HSBC Credit Card",
            "category": "Banking & Finance",
            "type": "cpa",
            "payout": "₹3000",
            "status": "inactive"
        }
    ]
}

export default function AllStores() {
    const subid=123456;
    const [allStores, setAllStores] = useState([]); // Store all fetched data
    const [displayedStores, setDisplayedStores] = useState([]); // Stores currently displayed
    const [loading, setLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const [searchQuery, setSearchQuery] = useState(''); // State for the search query
    const itemsPerLoad = 40; // Number of items to display on each load

    // Use sample data instead of fetching from API
    useEffect(() => {
        setLoading(true);
        setTimeout(() => {
            const stores = sampleData.stores.filter(store => store.status === 'active');
            setAllStores(stores);
            setDisplayedStores(stores.slice(0, itemsPerLoad));
            setHasMore(stores.length > itemsPerLoad);
            setLoading(false);
        }, 10); // Simulate network delay for better UX
    }, []);

    useEffect(() => {
        const handleScroll = () => {
            const windowHeight = window.innerHeight;
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            const documentHeight = document.documentElement.offsetHeight || document.body.offsetHeight;
            const remainingScroll = documentHeight - (windowHeight + scrollTop);

            if (remainingScroll < windowHeight * 2 && !loading && hasMore) {
                loadMoreStores();
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [loading, displayedStores, hasMore]);

    // Load more stores
    const loadMoreStores = () => {
        setLoading(true);
        setTimeout(() => {
            const currentLength = displayedStores.length;
            const moreStores = allStores.slice(currentLength, currentLength + itemsPerLoad);
            setDisplayedStores((prevStores) => [...prevStores, ...moreStores]);

            if (currentLength + moreStores.length >= allStores.length) {
                setHasMore(false);
            }
            setLoading(false);
        }, 10); // Simulate a network delay for better UX
    };

    // Filter stores based on the search query
    const filteredStores = displayedStores.filter((store) =>
        store.merchant.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <>
            <Helmet>
                <title>Explore Featured Stores - Top Online Shopping Deals</title>
                <meta
                    name="description"
                    content="Discover the best deals on Amazon, Flipkart, Myntra, Nykaa, AJIO, and Mamaearth. Shop your favorite products from featured stores."
                />
            </Helmet>

            {/* main content section */}
            <div className="w-full bg-light_green-300 overflow-x-hidden min-h-screen">
                {/* left sidebar section */}
                <div className="flex flex-col items-center">
                    <div className="relative flex flex-col items-center w-full">
                        {/* store categories section */}
                        <div className="relative w-full bg-gray-900_1e py-10 md:py-5">
                            <div className="relative w-full">
                                <div className="flex justify-center w-full md:px-10">
                                    <HeadingCards
                                        size="s"
                                        as="h1"
                                        className="italic !text-green-900 pb-10"
                                    >
                                        All Stores
                                    </HeadingCards>
                                </div>
                                {/* search bar section */}
                                <div className="flex justify-center w-full md:px-10 mb-4">
                                    <div className="relative w-full max-w-md">
                                        <input
                                            type="text"
                                            placeholder="Search stores..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="w-full px-8 border border-transparent rounded-full shadow-lg bg-glass-3d text-gray-800"
                                            style={{ height: '50px',borderRadius:"1.5rem",paddingLeft:'2rem' }}
                                        />
                                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                className="h-6 w-6 text-green-600"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                            >
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M10 19a9 9 0 100-18 9 9 0 000 18z"
                                                />
                                                <path
                                                    strokeLinecap="round"
                                                    strokeLinejoin="round"
                                                    strokeWidth={2}
                                                    d="M21 21l-4.35-4.35"
                                                />
                                            </svg>
                                        </div>
                                    </div>
                                </div>

                                {/* store grid section */}
                                <div className="grid w-full justify-items-center items-center px-2 grid-cols-4 justify-center gap-[20px] md:grid-cols-3 sm:grid-cols-2 md:gap-[10px]">
                                    {filteredStores.map((card, index) => (
                                        <div
                                            key={index}
                                            className="flex w-[206px] rounded-[24px] md:w-[170px] md:h-[152px] sm:w-[160px]"
                                            style={{
                                                boxShadow:
                                                    "-16px -16px 32px 0px rgba(186, 221, 158, 1)",
                                            }}
                                        >
                                            <div className="flex w-full flex-col items-center rounded-[24px] bg-white-A700 pb-4">
                                                <Img
                                                    src="images/img_group_15.svg"
                                                    alt="group image"
                                                    className="h-[125px] w-full rounded-tl-[24px] rounded-tr-[24px] md:h-auto sm:w-[150px]"
                                                />
                                                <div className="relative mt-[-120px] mr-0 md:mt-[-75px] sm:mt-[-65px] md:gap-[10px] flex flex-col gap-[15px]">
                                                    <div className="rounded-[30px] bg-glass shadow-sm w-[182px] md:w-[155px] md:h-[90px] sm:w-[148px]">
                                                        <Img
                                                            src={card.logo}
                                                            alt={card.merchant}
                                                            className="h-[106px] rounded-[30px] object-contain bg-white-A700 w-[182px] md:w-[155px] md:h-[90px] sm:w-[145px]"
                                                        />
                                                    </div>
                                                    <ButtonCards
                                                        shape="round"
                                                        className="h-[44px] w-[182px] md:w-[155px] sm:w-[145px]"
                                                        onClick={() =>
                                                            window.open(`${card.url}${subid}`,'_blank')
                                                        }
                                                    >
                                                        Shop on{" "}
                                                        {card.merchant.length > 12
                                                            ? `${card.merchant.slice(0, 12)}...`
                                                            : card.merchant}
                                                    </ButtonCards>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                {loading && <div className="text-center mt-5">Loading...</div>}
                                {/* separator line section */}
                                <div className="w-full">
                                    <div className="h-px border-t-[0.5px] border-solid border-white-A700 bg-light_green-A100" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <style jsx>{`
                .bg-glass-3d {
                    background: linear-gradient(
                        117.29deg,
                        rgba(255, 255, 255, 0.2) 2.7%,
                        rgba(255, 255, 255, 0.1) 98.49%
                    );
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.18);
                }
                .bg-glass {
                    background: linear-gradient(
                        117.29deg,
                        rgba(255, 255, 255, 0.4) 2.7%,
                        rgba(255, 255, 255, 0.1) 98.49%
                    );
                    box-shadow: 0px 20px 40px 0px rgba(0, 0, 0, 0.25);
                }

                .custom-button {
                    font-size: 14px; /* Adjust font size as needed */
                    white-space: nowrap; /* Prevent text from wrapping */
                    overflow: hidden; /* Hide overflowing text */
                    text-overflow: ellipsis; /* Show ellipsis (...) for overflow */
                }
            `}</style>
        </>
    );
}