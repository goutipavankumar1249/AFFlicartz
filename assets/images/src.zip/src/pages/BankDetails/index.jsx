import { Helmet } from "react-helmet";
import { Img, ButtonContact, HeadingPage } from "../../components";
import HeaderHome from "components/HeaderHome";
import React from "react";

export default function BankDetailsPage() {
  return (
    <>
      <Helmet>
        <title>Bank Details - Update Your Account Information | AfflicartZ</title>
        <meta
          name="description"
          content="Keep your bank details up-to-date for seamless transactions with AfflicartZ. Update your account holder name, account number, and more."
        />
      </Helmet>

      {/* main content section */}
      <div className="w-full bg-light_green-300">
        {/* header section */}
        <div className="relative h-[1024px]">
          {/* bank details section */}
          <div className="absolute bottom-0 left-0 right-0 top-0 m-auto flex h-max w-full flex-col">
            {/* divider line section */}
            <div className="relative z-[1] flex flex-col items-center gap-[27px]">
              {/* logo and navigation section */}

              {/* header section */}
              {/* <HeaderHome /> */}

              <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-white-A700_01 bg-light_green-A100" />
            </div>

            {/* bank information section */}
            <div className="relative mt-[-3px] flex w-[95%] items-start md:w-full md:flex-col md:p-5">
              <Img
                src="images/img_rectangle_97_905x719.png"
                alt="main image"
                className="mt-[-15px] block h-[940px] w-[50%] object-cover md:w-full"
              />

              {/* update bank details button section */}
              <div className="relative ml-[-606px] mt-7 flex flex-1 items-center md:ml-0 md:flex-col md:self-stretch">
                {/* payment information section */}
                <div className="flex flex-1 items-start justify-between gap-5 md:flex-col md:self-stretch">
                  {/* account details columns section */}
                  <div className="z-[3] w-[54%] md:w-full">
                    <div className="flex flex-col items-end gap-[95px] md:gap-[71px] sm:gap-[47px]">
                      <div className="flex w-[90%] items-center justify-between gap-5 md:w-full">
                        <Img
                          src="images/img_image_1.png"
                          alt="brand logo"
                          className="z-10 h-[116px] w-[116px] object-cover"
                        />
                        <HeadingPage size="xl" as="h1" className="!font-inter !text-black-900">
                          <span className="text-green-900">A</span>
                          <span className="text-black-900">fflicart</span>
                          <span className="text-green-900">Z</span>
                        </HeadingPage>
                      </div>
                      <Img
                        src="images/img_payment_information_bro.svg"
                        alt="payment image"
                        className="mr-4 h-[467px] w-[467px] md:mr-0"
                      />
                    </div>
                  </div>

                  {/* additional account details section */}
                  <div className="mt-[29px] flex w-[29%] flex-col gap-[19px] md:w-full">
                    <div className="flex flex-col items-start">
                      <HeadingPage as="h2" className="tracking-[0.40px] !text-gray-700">
                        Account Holder
                      </HeadingPage>
                      <HeadingPage size="md" as="h3" className="tracking-[0.60px]">
                        SALVE SURYARAJ
                      </HeadingPage>
                    </div>
                    <div className="flex flex-col items-start">
                      <HeadingPage as="h4" className="tracking-[0.40px] !text-gray-700">
                        Account Number
                      </HeadingPage>
                      <HeadingPage size="md" as="h5" className="tracking-[0.60px]">
                        2144 2493 2349
                      </HeadingPage>
                    </div>
                    <div className="flex flex-col items-start">
                      <HeadingPage as="h6" className="tracking-[0.40px] !text-gray-700">
                        IFS Code
                      </HeadingPage>
                      <HeadingPage size="md" as="h3" className="tracking-[0.60px]">
                        SBIN0023423
                      </HeadingPage>
                    </div>
                    <div className="flex flex-col items-start">
                      <HeadingPage as="h5" className="tracking-[0.40px] !text-gray-700">
                        Phone Number
                      </HeadingPage>
                      <HeadingPage size="md" as="h3" className="tracking-[0.60px]">
                        998827721001
                      </HeadingPage>
                    </div>
                  </div>
                </div>
                <ButtonContact
                  rightIcon={<Img src="images/img_edit_white_a700_01.svg" alt="edit" className="h-[18px] w-[18px]" />}
                  className="relative z-10 mb-[250px] ml-[-320px] mr-[-20px] flex h-[35px] min-w-[644px] flex-row items-center justify-center gap-[35px] self-end rounded-[17px] bg-green-900 px-[35px] text-center text-xl tracking-[0.40px] text-white-A700_01 md:ml-0 sm:px-5"
                >
                  Update Bank Details
                </ButtonContact>
              </div>
            </div>
          </div>
          <Img
            src="images/img_group_5.png"
            alt="featured image"
            className="absolute bottom-0 left-[0.00px] top-0 my-auto h-[1024px] w-[82%] object-cover"
          />
        </div>
      </div>
    </>
  );
}
