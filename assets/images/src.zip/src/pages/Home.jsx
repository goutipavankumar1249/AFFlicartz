import { Helmet } from "react-helmet";
import { TextHome, ImgHome, HeadingHome, ButtonHome } from "../components";
import Desktop1Stacksignup from "../components/Desktop1Stacksignup";
import HeaderHome from "../components/HeaderHome";
import React, { Suspense } from "react";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>AfflicartZ | Earn Cashback on Every Purchase</title>
        <meta
          name="description"
          content="Join AfflicartZ and earn cashback on every purchase. Shop at your favorite stores, learn how it works, and start saving today with exclusive cashback offers."
        />
      </Helmet>

      {/* main layout section */}
      <div className="w-full bg-gradient-to-b from-[#A8C879] to-[#d2ffaf] " >
        {/* header section */}
        <div className="flex flex-col">
          <div className="h-[367px]"></div>
          {/* <ImgHome src="images/img_ellipse_1.png" alt="hero image" className="mt-[21px] h-[514px] w-[37%] object-fit" /> */}
          <div className="relative mt-[-367px] flex flex-col items-end">
            <ImgHome src="images/img_ellipse_2.png" alt="ellipse image" className="h-[390px] w-[24%] object-cover" />

            {/* hero section //bg-[#1212121e] */}
            <div className="relative mt-[-390px] self-stretch  pb-[159px] pt-[26px] md:pb-5 sm:py-5">
              <div className="flex flex-col items-center gap-[27px]">
                {/* <HeaderHome /> */}
                <div className="relative h-[1152px] self-stretch md:h-auto">
                  <div className="absolute left-0 right-0 top-[10%] m-auto h-[551px] w-[37%] rounded-[50%] bg-[#dbfebf] blur-[200.00px] backdrop-opacity-[0.5]" />
                  {/* <ImgHome
                    src="images/img_image_removebg_preview.png"
                    alt="imageremovebg"
                    className="absolute left-[0.00px] top-[3%] m-auto h-[514px] w-[38%] object-cover"
                  /> */}
                  <ImgHome
                    src="images/img_image_removebg_preview_514x526.png"
                    alt="imageremovebg"
                    className="mt-[21px] h-[514px] w-[37%] object-cover"
                  />

                  {/* how it works section */}
                  <div className="absolute bottom-0 left-0 right-0 top-0 m-auto h-max w-full">
                    <div className="relative z-[1] flex flex-col items-end gap-[57px] sm:gap-7">
                      <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-[#ffffff] bg-[#c5ff96]" />
                      <div className="flex w-[59%] flex-col gap-[54px] md:w-full md:p-5 sm:gap-[27px]">
                        <div className="flex flex-col items-start gap-10">
                          <div className="flex flex-col items-start gap-1">
                            <HeadingHome size="xl" as="h1" className="italic !text-[#105c0a]">
                              Earn Cashback
                            </HeadingHome>
                            <HeadingHome size="lg" as="h2" className="italic !text-[#5c5c5c]">
                              on Every Purchase
                            </HeadingHome>
                          </div>
                          <TextHome as="p" className="italic">
                            <span className="font-['Shrikhand'] font-normal text-[#105c0a]">“</span>
                            <span className="text-[#105c0a]">Shop at your favorite stores and get money back!</span>
                            <span className="font-['Shrikhand'] font-normal text-[#105c0a]">“</span>
                          </TextHome>
                        </div>
                        <div className="mx-auto flex w-full max-w-[620px] items-center gap-5">
                          <ButtonHome className="flex h-[88px] min-w-[300px] flex-row items-center justify-center rounded-[16px] border border-solid border-[#00000014] bg-[#105c0a] px-8 text-center text-xl font-extrabold italic text-[#ffffff] shadow-[0px_16px_32px_0px_#000000] sm:px-5">
                            Shop Now
                          </ButtonHome>
                          <ButtonHome
                            rightIcon={
                              <ImgHome src="images/img_arrowright.svg" alt="arrow-right" className="h-[29px] w-[29px]" />
                            }
                            className="flex h-[93px] min-w-[300px] flex-row items-center justify-center gap-4 rounded-[16px] border border-solid border-[#00000014] bg-[#c2e1ab] px-8 text-center text-xl font-extrabold italic text-[#11640b] shadow-[0px_16px_32px_0px_#000000] sm:px-5"
                          >
                            Learn More
                          </ButtonHome>
                        </div>
                      </div>
                      <div className="self-stretch">
                        <div className="h-px self-end border-t-[0.5px] border-solid border-[#ffffff] bg-[#c5ff96]" />
                      </div>
                    </div>

                    {/* steps section */}
                    <div className="relative mt-[-20px] h-[620px]">
                      <ImgHome
                        src="images/img_vector.png"
                        alt="vector"
                        className="absolute bottom-[24.00px] left-[0.00px] m-auto h-[343px] w-[18%] object-cover"
                      />
                      <ImgHome
                        src="images/img_vector_light_green_300.png"
                        alt="vector"
                        className="absolute right-[0.00px] top-[9%] m-auto h-[312px] w-[13%] object-cover"
                      />
                      <ImgHome
                        src="images/img_vector_light_green_300_238x301.svg"
                        alt="vector"
                        className="absolute bottom-[0.00px] right-[31%] m-auto h-[238px] w-[21%]"
                      />
                      <div className="absolute bottom-0 right-[11.00px] top-0 my-auto flex h-max w-[92%] flex-col">
                        <ImgHome
                          src="images/img_vector_light_green_300_286x287.svg"
                          alt="decorative image"
                          className="ml-[355px] h-[286px] w-[287px] md:ml-0"
                        />
                        <div className="relative mt-[-206px] flex flex-col items-center gap-5">
                          <HeadingHome size="md" as="h3" className="!font-semibold italic !text-[#105c0a]">
                            How it works?
                          </HeadingHome>
                          <div className="flex flex-col items-center gap-6 self-stretch border-none">
                            <div className="flex items-center self-stretch md:flex-col">
                              <div className="flex w-[25%] flex-col items-center gap-[18px] self-start md:w-full md:p-5">
                                <a href="#" className="italic">
                                  <HeadingHome size="md" as="h4" className="!text-[#5c5c5c]">
                                    Sign Up
                                  </HeadingHome>
                                </a>
                                <div className="white_A700_99_white_A700_99_border flex flex-col items-center gap-[30px] self-stretch rounded-[24px]  bg-gradient-to-b from-[#ffffff66] to-[#ffffff19] px-[15px] pb-[34px] pt-[35px] shadow-[0px_20px_40px_0px_#0000003f] sm:py-5">
                                  <HeadingHome
                                    size="s"
                                    as="h5"
                                    className="w-[98%] text-center italic leading-[35px] !text-[#105c0a] md:w-full"
                                  >
                                    Join our community to start earning cashback
                                  </HeadingHome>
                                  <HeadingHome
                                    as="h6"
                                    className="w-full text-center !font-semibold italic leading-[23px] !text-[#7c8576]"
                                  >
                                    Create your free account to gain access to exclusive cashback offers from top
                                    retailers.
                                  </HeadingHome>
                                </div>
                              </div>
                              <ImgHome
                                src="images/img_freepik_charac.svg"
                                alt="character image"
                                className="h-[316px] w-[7%] md:w-full"
                              />
                              <div className="ml-[39px] flex flex-1 md:ml-0 md:flex-col md:self-stretch md:p-5">
                                <Suspense fallback={<div>Loading feed...</div>}>
                                  {
                                    <Desktop1Stacksignup
                                      title="Shop"
                                      description1="Shop at your favorite stores through our platform."
                                      description2=" Browse our partnered stores, click through our links, and shop as usual to earn cashback."
                                      image="images/img_character_1.svg"
                                      
                                      className="h-[349px] flex-1 md:w-full md:flex-none"
                                    />
                                  }
                                </Suspense>
                              </div>
                              <div className="ml-[39px] flex flex-1 md:ml-0 md:flex-col md:self-stretch md:p-5">
                                <Suspense fallback={<div>Loading feed...</div>}>
                                  {
                                    <Desktop1Stacksignup
                                      title="CashBack"
                                      description1="Receive cashback on evry purcahse made."
                                      description2=" Your cashback rewards will be tracked and credited to your account automatically "
                                      image="images/img_freepik_charac.svg"
                                      
                                      className="h-[349px] flex-1 md:w-full md:flex-none"
                                    />
                                  }
                                </Suspense>
                              </div>
                            </div>
                            <TextHome as="p" className="italic">
                              <span className="font-['Shrikhand'] font-normal text-[#105c0a]">“</span>
                              <span className="text-[#105c0a]">It’s that simple!</span>
                              <span className="font-['Shrikhand'] font-normal text-[#105c0a]">“</span>
                            </TextHome>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
