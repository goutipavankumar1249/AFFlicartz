import React from 'react';
import { useParams } from 'react-router-dom';

const sampleData = {
    "result": {
        "data": [
            {
                id: 3128530,
                transaction_id: "6655d82d0e566304abe52bd5",
                sale_amount: "199",
                status: "pending",
                store_name: "Myntra",
                sale_date: "2024-05-28 18:42:13",
                user_commission: "71.928"
            },
            {
                id: 3128556,
                transaction_id: "6655d87322416c04b4c554cb",
                sale_amount: "299",
                status: "success",
                store_name: "Amazon",
                sale_date: "2024-05-28 18:43:23",
                user_commission: "43.128"
            },
            {
                id: 3100000,
                transaction_id: "6655d87322416c04b4c554cb",
                sale_amount: "399",
                status: "cancelled",
                store_name: "Flipkart",
                sale_date: "2024-05-28 18:43:23",
                user_commission: "43.128"
            }
        ]
    }
};
const storeImages = {
    Myntra: 'images/Myntra.png',
    Amazon: 'images/Amazon.png',
    Flipkart: 'images/Flipkart.png'
};

const OrderDetails = () => {
    const { id } = useParams();
    const card = sampleData.result.data.find((item) => item.id === parseInt(id));


    return (
        <div className="p-6  h-[87vh]  bg-light_green-200 bg-[url(/public/images/img_group_5.png)] bg-cover bg-no-repeat">
            {card ? (
                <div className="flex items-center flex-col shadow-lg rounded-lg p-4 mb-4 bg-light_green-200">
                    <div className='flex items-center w-full'>
                        <img src={storeImages[card.store_name]} alt={card.store_name} className="w-16 h-16 mr-4 object-contain" />
                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Cashback</div>
                            <div className="text-lg font-semibold">₹{card.user_commission}</div>
                        </div>
                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Cashback %</div>
                            <div className="text-lg font-semibold">10%</div>
                        </div>
                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Order ID</div>
                            <div className="text-lg font-semibold">{card.transaction_id}</div>
                        </div>
                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Order Amount</div>
                            <div className="text-lg font-semibold">₹{card.sale_amount}</div>
                        </div>
                        <button
                            className={`text-white font-semibold py-2 px-4 rounded-full ${card.status === 'success' ? 'bg-green-500' :
                                card.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                                }`}
                        >
                            {card.status.charAt(0).toUpperCase() + card.status.slice(1)}
                        </button>
                        <button
                            className="bg-green-800 ml-[5px] text-white-A700 ont-semibold py-2 px-4 flex rounded-full"
                        >
                            Get Help
                        </button>
                    </div>
                    <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-[#ffffff] bg-[#c5ff96]" />
                    <div className='flex items-center w-full justify-around pt-[10px]'>
                        
                        <div className="pr-[10%] pl-[10%]">
                            <div className="text-gray-500 text-sm">Cashback</div>
                            <div className="text-lg font-semibold">₹{card.user_commission}</div>
                        </div>
                        
                        <div className="pr-[10%] pl-[10%]">
                            <div className="text-gray-500 text-sm">Order Amount</div>
                            <div className="text-lg font-semibold">₹{card.sale_amount}</div>
                        </div>
                        
                    </div>
                </div>
            ) : (
                <p>Card not found</p>
            )}
        </div>
    );
};

export default OrderDetails;
