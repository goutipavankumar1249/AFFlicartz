import React from 'react';
import { Link } from 'react-router-dom';
import { IoIosArrowForward } from 'react-icons/io';

const sampleData = {
    result: {
        data: [
            {
                id: 3128530,
                transaction_id: "6655d82d0e566304abe52bd5",
                sale_amount: "199",
                status: "pending",
                store_name: "Myntra",
                sale_date: "2024-05-28 18:42:13",
                user_commission: "71.928"
            },
            {
                id: 3128556,
                transaction_id: "6655d87322416c04b4c554cb",
                sale_amount: "299",
                status: "success",
                store_name: "Amazon",
                sale_date: "2024-05-28 18:43:23",
                user_commission: "43.128"
            },
            {
                id: 3100000,
                transaction_id: "6655d87322416c04b4c554cb",
                sale_amount: "399",
                status: "cancelled",
                store_name: "Flipkart",
                sale_date: "2024-05-28 18:43:23",
                user_commission: "43.128"
            }
        ]
    }
};

const storeImages = {
    Myntra: 'images/Myntra.png',
    Amazon: 'images/Amazon.png',
    Flipkart: 'images/Flipkart.png'
};

const Orders = () => {
    const { data } = sampleData.result;

    return (
        <div className="p-6 min-h-screen bg-light_green-200 bg-[url(/public/images/img_group_5.png)] bg-cover bg-no-repeat">
            {data.map(order => (
                <div key={order.id} className="flex md:items-stretch items-center shadow-lg rounded-lg p-4 mb-4 bg-light_green-200 md:flex-col lg:flex-row">
                    <div className='flex items-center'>
                    </div>
                    <div className='flex items-center justify-between'>
                        <img src={storeImages[order.store_name]} alt={order.store_name} className="w-16 h-16 mr-4 object-contain" />
                        <button
                            className={`text-white font-semibold py-2 w-24 px-4 rounded-full ${order.status === 'success' ? 'bg-green-500' :
                                order.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                                } md:block hidden`}
                            style={{
                                backgroundColor: order.status === 'success' ? 'rgba(40, 167, 69, 1)' :
                                    order.status === 'pending' ? 'rgba(255, 193, 7, 1)' : 'rgba(220, 53, 69, 1)',
                                    color: 'white'
                            }}
                        >
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </button>
                    </div>

                    <div className="border-t border-white w-full my-2 hidden md:block"></div>
                    <div className='items-center justify-around hidden md:flex'>

                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Cashback</div>
                            <div className="text-lg font-semibold">₹{order.user_commission}</div>
                        </div>
                        <div className="flex flex-col">
                            <div className="text-gray-500 text-sm">Cashback %</div>
                            <div className="text-lg font-semibold">10%</div>
                        </div>
                    </div>
                    <div className="flex-1 md:hidden block">
                        <div className="text-gray-500 text-sm">Cashback</div>
                        <div className="text-lg font-semibold">₹{order.user_commission}</div>
                    </div>
                    <div className="flex-1 md:hidden block">
                        <div className="text-gray-500 text-sm">Cashback %</div>
                        <div className="text-lg font-semibold">10%</div>
                    </div>
                    <div className="border-t border-white w-full my-2 hidden md:block"></div>
                    <div className="flex-1">
                        <div className="text-gray-500 text-sm">Order ID</div>
                        <div className="text-lg font-semibold">{order.transaction_id}</div>
                    </div>
                    <div className='items-center justify-around hidden md:flex'>
                        <div className="flex-1">
                            <div className="text-gray-500 text-sm">Order Amount</div>
                            <div className="text-lg font-semibold">₹{order.sale_amount}</div>
                        </div>
                        <Link to={`/orders/${order.id}`} className="text-blue-500 ml-4 flex items-center">
                            View More <IoIosArrowForward className="ml-1" />
                        </Link>
                    </div>
                    <div className="flex-1 md:hidden block">
                        <div className="text-gray-500 text-sm">Order Amount</div>
                        <div className="text-lg font-semibold">₹{order.sale_amount}</div>
                    </div>
                    <button
                        className={`text-white font-semibold py-2 px-4 w-24 rounded-full ${order.status === 'success' ? 'bg-green-500' :
                            order.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                            } md:hidden block`}
                        style={{
                            backgroundColor: order.status === 'success' ? 'rgba(40, 167, 69, 1)' :
                                order.status === 'pending' ? 'rgba(255, 193, 7, 1)' : 'rgba(220, 53, 69, 1)',
                                color: 'white'
                        }}
                    >
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </button>
                    <Link to={`/orders/${order.id}`} className="text-blue-500 font-bold ml-4 flex items-center md:hidden ">
                        View More <IoIosArrowForward className="ml-1" />
                    </Link>
                </div>
            ))}
        </div>
    );
};


export default Orders;