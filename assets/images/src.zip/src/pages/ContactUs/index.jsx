import { Helmet } from "react-helmet";
import { ImgContact, TextContact, ButtonContact, HeadingContact } from "../../components";
import HeaderHome from "../../components/HeaderHome";
import React from "react";

export default function ContactUsPage() {
  return (
    <>
      <Helmet>
        <title>Contact AfflicartZ - Get in Touch with Our Support Team</title>
        <meta
          name="description"
          content="Reach out to AfflicartZ for customer support via email, social media, or phone. Our team is ready to assist you with your inquiries and provide the help you need."
        />
      </Helmet>

      {/* contact us page section */}
      <div className="w-full bg-light_green-300 overflow-x-hidden overflow-y-auto"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
        {/* main content section */}
        <div className="relative h-[1024px]">
          {/* contact info section */}
          <div className="absolute bottom-0 left-0 right-0 top-0 mt-[10px] h-max w-full">
            {/* header section */}
            <div className="relative z-[1] flex flex-col items-center gap-[27px]">
              {/* <HeaderHome /> */}
              <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-white-A700 bg-light_green-A100" />
            </div>

            {/* contact details section */}
            <div className="relative mt-[-3px] flex items-start md:flex-col">
              <ImgContact
                src="images/img_rectangle_97.png"
                alt="product image"
                className="h-[905px] w-[50%] object-cover md:w-full"
              />

              {/* contact methods section */}
              <div className="relative ml-[-691px] mt-7 flex flex-1 items-center md:ml-0 md:flex-col md:self-stretch md:p-5">
                <div className="flex-1 md:self-stretch">
                  <div className="flex items-center gap-10 md:flex-col">
                    <div className="flex-1 md:self-stretch">
                      <div className="flex flex-col items-end gap-[68px] sm:gap-[34px]">
                        <div className="mr-24 flex w-[76%] items-center justify-center gap-10 md:mr-0 md:w-full">
                          <ImgContact
                            src="images/img_image_1.png"
                            alt="afflicart image"
                            className="h-[116px] w-[116px] object-cover"
                          />
                          <HeadingContact size="lg" as="h1" className="!text-black-900">
                            <span className="text-green-900">A</span>
                            <span className="text-black-900">fflicart</span>
                            <span className="text-green-900">Z</span>
                          </HeadingContact>
                        </div>
                        <ImgContact
                          src="images/img_contact_us_cuate.svg"
                          alt="contact image"
                          className="mr-[25px] h-[301px] w-[90%] md:mr-0"
                        />
                        <HeadingContact
                          size="s"
                          as="h2"
                          className="w-full text-center leading-9 tracking-[0.60px] !text-green-900"
                        >
                          You can get in touch with us through below platforms. Our Team will reach out to you as soon
                          as it would be possible.
                        </HeadingContact>
                      </div>
                    </div>
                    <div className="flex w-[34%] flex-col items-start md:w-full">
                      <HeadingContact size="md" as="h3" className="tracking-[0.80px] !text-green-900">
                        Customer Support
                      </HeadingContact>
                      <ButtonContact className="ml-[31px] mt-[15px] flex h-[46px] w-[47px] items-center justify-center rounded-[23px] bg-light_green-200 p-2.5 md:ml-0">
                        <ImgContact src="images/img_call.svg" />
                      </ButtonContact>
                      <ButtonContact className="ml-8 mt-[13px] flex h-[47px] w-[47px] items-center justify-center rounded-[23px] bg-light_green-200 px-3 md:ml-0">
                        <ImgContact src="images/img_lock.svg" />
                      </ButtonContact>
                      <HeadingContact size="md" as="h4" className="mt-[54px] tracking-[0.80px] !text-green-900">
                        Social Media
                      </HeadingContact>
                      <ImgContact
                        src="images/img_info.png"
                        alt="info image"
                        className="ml-[35px] mt-[31px] h-[40px] w-[40px] object-cover md:ml-0"
                      />
                      <div className="ml-[35px] mt-[13px] w-[13%] rounded-[20px] bg-red-900 px-[9px] pb-3 pt-[11px] md:ml-0 md:w-full">
                        <div className="flex h-[15px] items-center justify-center bg-[url(/public/images/img_group_4.svg)] bg-cover bg-no-repeat p-[5px] md:h-auto">
                          <ImgContact src="images/img_path.svg" alt="path image" className="h-[5px] w-[5px]" />
                        </div>
                      </div>
                      <ButtonContact className="ml-[35px] mt-[9px] flex h-[40px] w-[40px] items-center justify-center rounded-[20px] bg-blue-300 px-2.5 md:ml-0">
                        <ImgContact src="images/img_trash.svg" />
                      </ButtonContact>
                      <ImgContact
                        src="images/img_volume.svg"
                        alt="volume image"
                        className="ml-[34px] mt-2.5 h-[40px] w-[40px] md:ml-0"
                      />
                      <ImgContact
                        src="images/img_group_3204.png"
                        alt="brand image"
                        className="ml-[35px] mt-2.5 h-[40px] w-[40px] object-cover md:ml-0"
                      />
                    </div>
                  </div>
                </div>
                <div className="relative mb-[30px] ml-[-355px] flex flex-col items-start self-end md:ml-0">
                  <TextContact as="p" className="ml-[5px] tracking-[0.40px] md:ml-0">
                    <span className="text-white-A700">Contact Number:&nbsp;</span>
                    <span className="text-3xl text-green-900">+91 929102810121&nbsp;</span>
                  </TextContact>
                  <TextContact as="p" className="ml-[5px] mt-8 tracking-[0.40px] md:ml-0">
                    <span className="text-white-A700">Email Address:&nbsp;</span>
                    <span className="text-3xl text-green-900">help@afflicartz.com</span>
                  </TextContact>
                  <TextContact as="p" className="ml-[5px] mt-36 tracking-[0.40px] md:ml-0">
                    <span className="text-white-A700">Instagram :&nbsp;</span>
                    <span className="text-3xl text-green-900">@afflicartz_insta&nbsp;</span>
                  </TextContact>
                  <TextContact as="p" className="mt-5 tracking-[0.40px]">
                    <span className="text-white-A700">Youtube :&nbsp;</span>
                    <span className="text-3xl text-green-900">@afflicartz_yt&nbsp;</span>
                  </TextContact>
                  <TextContact as="p" className="mt-5 tracking-[0.40px]">
                    <span className="text-white-A700">Twitter :&nbsp;</span>
                    <span className="text-3xl text-green-900">@afflicartz_twitter</span>
                  </TextContact>
                  <TextContact as="p" className="mt-5 tracking-[0.40px]">
                    <span className="text-white-A700">Whatsapp :&nbsp;</span>
                    <span className="text-3xl text-green-900">@afflicartz_whatsapp</span>
                  </TextContact>
                  <TextContact as="p" className="mt-5 tracking-[0.40px]">
                    <span className="text-white-A700">Telegram :&nbsp;</span>
                    <span className="text-3xl text-green-900">@afflicartz_telegram</span>
                  </TextContact>
                </div>
              </div>
            </div>
          </div>
          {/* <ImgContact
            src="images/img_group_3190.png"
            alt="secondary image"
            className="absolute bottom-0 left-[0.00px] top-0 z-[2] my-auto h-[1024px] w-[82%] object-cover"
          /> */}
        </div>
      </div>
    </>
  );
}
