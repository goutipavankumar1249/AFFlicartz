import { Helmet } from "react-helmet";
import { HeadingCards, Img, ButtonCards } from "../../components";
import React from "react";
import CardData from "../CardData.json"; // Import your card data JSON file

export default function FeaturedStores() {
  return (
    <>
      <Helmet>
        <title>Explore Featured Stores - Top Online Shopping Deals</title>
        <meta
          name="description"
          content="Discover the best deals on Amazon, Flipkart, Myntra, Nykaa, AJIO, and Mamaearth. Shop your favorite products from featured stores."
        />
      </Helmet>

      {/* main content section */}
      <div className="w-full bg-light_green-300 overflow-x-hidden min-h-screen">
        {/* left sidebar section */}
        <div className="flex flex-col items-center">
          <div className="relative flex flex-col items-center w-full">
            {/* store categories section */}
            <div className="relative w-full bg-gray-900_1e py-10 md:py-5">
              <div className="relative w-full">
                <div className="absolute bottom-0 left-0 right-0 top-0 min-h-screen w-full">
                  <div className="absolute bottom-0 left-0 right-0 m-auto h-[551px] w-[37%] rounded-[50%] bg-light_green-100 blur-[200.00px] backdrop-opacity-[0.5]" />
                  <div className="relative w-full flex flex-col items-center gap-[59px] sm:gap-[29px]">
                    <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-white-A700 bg-light_green-A100" />
                    <div className="flex justify-center w-full md:px-10">
                      <HeadingCards size="s" as="h1" className="italic !text-green-900">
                        Featured Stores
                      </HeadingCards>
                    </div>

                    {/* store grid section */}
                    <div className="grid w-full justify-items-center items-center px-2 grid-cols-4 justify-center gap-[20px] md:grid-cols-3 sm:grid-cols-2 md:gap-[10px]">
                      {CardData.cards.map((card, index) => (
                        <div
                          key={index}
                          className="flex w-[206px] rounded-[24px] md:w-[170px] md:h-[152px] sm:w-[160px]"
                          style={{
                            boxShadow: "-16px -16px 32px 0px rgba(186, 221, 158, 1)",
                          }}
                        >
                          <div className="flex w-full flex-col items-center rounded-[24px] bg-white-A700 pb-4">
                            <Img
                              src="images/img_group_15.svg"
                              alt="group image"
                              className="h-[125px] w-full rounded-tl-[24px] rounded-tr-[24px] md:h-auto sm:w-[150px]"
                            />
                            <div className="relative mt-[-120px] mr-0 md:mt-[-75px] sm:mt-[-65px] md:gap-[10px] flex flex-col gap-[15px]">
                              <div className="rounded-[30px] bg-glass shadow-sm w-[182px] md:w-[155px] md:h-[90px] sm:w-[148px]">
                                <Img
                                  src={`images/${card.image[card.image.length - 1]}`}
                                  alt="rectangle image"
                                  className="h-[106px] rounded-[30px] object-contain bg-white-A700 w-[182px] md:w-[155px] md:h-[90px] sm:w-[145px]"
                                />
                              </div>
                              <ButtonCards shape="round" className=" h-[44px] w-[182px] md:w-[155px] sm:w-[145px]" path={"/"}>
                                Shop on {card.image[card.image.length - 1].slice(0, -4)}
                              </ButtonCards>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* separator line section */}
                    <div className="w-full">
                      <div className="h-px border-t-[0.5px] border-solid border-white-A700 bg-light_green-A100" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .bg-glass {
          background: linear-gradient(117.29deg, rgba(255, 255, 255, 0.4) 2.7%, rgba(255, 255, 255, 0.1) 98.49%);
        box-shadow: 0px 20px 40px 0px rgba(0, 0, 0, 0.25);

        }
      `}</style>
    </>
  );
}
