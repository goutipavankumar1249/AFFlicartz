import { Helmet } from "react-helmet";
import { HeadingAbout, TextAbout } from "../../components";
import AboutUsColumnOne from "../../components/AboutUsColumnOne";
import HeaderHome from "../../components/HeaderHome";
import React from "react";

export default function AboutUsPage() {
  return (
    <>
      <Helmet>
        <title>About AfflicartZ - Exclusive Student Cashback Offers</title>
        <meta
          name="description"
          content="Discover AfflicartZ's mission to provide students with exclusive cashback offers on online purchases. Enjoy a tailored shopping experience with top-notch data security and transparency."
        />
      </Helmet>

      <div className="scroll-smooth min-h-screen bg-[#a8c778] overflow-x-hidden overflow-y-auto">
        {/* Welcome section */}
        <AboutUsColumnOne />

        {/* Mission values section */}
        <div className="flex w-full flex-col items-center">
          {/* Navigation header section */}
          {/* <HeaderHome /> */}
          <div className="mt-[27px] h-px w-full self-stretch border-t-[0.5px] border-solid border-[#ffffff] bg-[#c5ff96]" />
          <div className="mt-14 flex w-[48%] flex-col items-start justify-start self-end md:mr-0 md:w-full md:p-5">
            <div className="flex flex-col items-start gap-4 self-stretch">
              <img
                src="images/img_about_us_page_bro.svg"
                alt="about us"
                className="md:block hidden mx-auto sm:w-[282px] sm:h-[214px] md:w-[382px]"
              />
              <TextAbout
                size="s"
                as="p"
                className="md:block hidden w-[98%] text-center leading-9 tracking-[0.60px] !text-[#000000] md:w-full"
              >
                <span className="text-[#105c0a]">Welcome to A</span>
                <span className="text-[#000000]">fflicart</span>
                <span className="text-[#105c0a]">
                  Z, your go-to destination for exclusive cashback offers on your favorite online purchases.
                </span>
              </TextAbout>
              <HeadingAbout size="md" as="h2" className="tracking-[0.80px]">
                Our Mission
              </HeadingAbout>
              <TextAbout as="p" className="w-full !font-medium leading-[30px] tracking-[0.40px]">
                At AfflicartZ, we are dedicated to making online shopping more rewarding for students. Our mission is to
                provide a seamless platform where students can earn cashback on every purchase they make through our
                partnered websites.
              </TextAbout>
            </div>
            <div className="mt-[33px] flex flex-col items-start gap-3 self-stretch">
              <HeadingAbout size="md" as="h3" className="tracking-[0.80px]">
                What sets us apart
              </HeadingAbout>
              <TextAbout as="p" className="w-full leading-[30px] tracking-[0.40px]">
                Unlike traditional cashback platforms, we prioritize the needs and preferences of students. Our
                user-friendly interface, curated selection of partner websites, and exclusive cashback offers are
                tailored to enhance the student shopping experience.
              </TextAbout>
            </div>
            <HeadingAbout size="md" as="h4" className="mt-[33px] tracking-[0.80px]">
              Why choose us
            </HeadingAbout>
            <TextAbout as="p" className="mt-5 w-full leading-[30px] tracking-[0.40px]">
              Student-Focused: We understand the unique challenges students face, which is why we&#39;ve designed our
              platform to cater specifically to their needs.
            </TextAbout>
            <TextAbout as="p" className="mt-2.5 w-full leading-[30px] tracking-[0.40px]">
              Transparency: We believe in transparency and honesty. You can trust us to provide accurate information and
              fair cashback rewards.
            </TextAbout>
            <TextAbout as="p" className="mt-2.5 w-full leading-[30px] tracking-[0.40px]">
              Data Security: Your privacy and security are our top priorities. We adhere to stringent data protection
              standards to ensure that your personal information is safe and secure.
            </TextAbout>
            <HeadingAbout size="md" as="h5" className="mt-[29px] tracking-[0.80px]">
              Get in touch
            </HeadingAbout>
            <TextAbout as="p" className="mt-6 w-full leading-[30px] tracking-[0.40px]">
              We love hearing from our users! If you have any questions, feedback, or suggestions, please don&#39;t
              hesitate to contact us at afflicartz@gmail.com.
            </TextAbout>
            <HeadingAbout size="md" as="h6" className="ml-3 w-full leading-[47px] tracking-[0.80px] md:ml-0">
              Thank you for choosing AfflicartZ for all your cashback needs!
            </HeadingAbout>
          </div>
        </div>
      </div>
    </>
  );
}
