import { Helmet } from "react-helmet";
// import { useState } from "react";
import { FaArrowRight } from 'react-icons/fa';
import { HeadingPage, ButtonContact, Img } from "../../components";
import EarningsColumnOne from "../../components/EarningsColumnOne";
import HeaderHome from "components/HeaderHome";
import React from "react";

export default function EarningsPage() {
  // const [showRecentOrders, setShowRecentOrders] = useState(false);

  // const handleToggleRecentOrders = () => {
  //   setShowRecentOrders((prevShow) => !prevShow);
  // };

  return (
    <>
      <Helmet>
        <title>Earnings - Track and Manage Your Cashback | AfflicartZ</title>
        <meta
          name="description"
          content="View your total earnings, recent transactions, and manage withdrawals on the AfflicartZ Earnings Page. Maximize rewards with exclusive promotions."
        />
      </Helmet>

      {/* earnings main section */}
      <div className="relative h-[1024px] md:h-screen min-h-screen w-full bg-light_green-300 overflow-x-hidden pt-[10px] overflow-y-auto object-cover"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
      <div className="h-px w-full self-stretch border-t-[0.5px] border-solid border-[#ffffff] bg-[#c5ff96]" />
        {/* earnings overview section */}
        <EarningsColumnOne />

        {/* earnings navigation section */}
        <div className="container-xs absolute left-0 right-0 top-[26.00px] md:mx-auto my-auto flex md:p-5">
          {/* earnings content section */}
          <div className="flex w-full flex-col items-center gap-[52px] sm:gap-[26px] md:flex md:">
            {/* earnings headerHome section */}
              {/* <HeaderHome  /> */}
            <div className="flex flex-col items-end gap-[105px] self-stretch md:gap-[78px] sm:gap-[52px]">
            <Img src="images/img_wallet_bro.svg" alt="walletimage" className="h-[192px] mx-auto md:block hidden" />
              {/* earnings summary section */}
              <div className="white_A700_99_white_A700_99_border flex w-[43%] flex-col gap-2 rounded-[24px] bg-gradient pb-[31px] pl-[26px] pr-[19px] pt-12 shadow-xs md:w-full md:pt-5 sm:py-5 sm:pl-5 md:mr-0 mr-[50px]" >
                <div className="flex flex-col items-end">
                  <HeadingPage size="md" as="h1" className="tracking-[0.60px] !text-gray-700">
                    Total Earnings in Wallet
                  </HeadingPage>
                  <HeadingPage size="lg" as="h2" className="mr-2 tracking-[0.80px] md:mr-0">
                    ₹119.80
                  </HeadingPage>
                </div>

                {/* earnings actions section */}
                <div>
                  <div className="flex flex-col items-center">
                    <ButtonContact className="flex h-[50px] w-full flex-row items-center justify-center rounded-[25px] border border-solid border-white-A700_7f bg-white-A700_01 px-[34px] text-center font-poppins text-lg font-bold text-green-900 shadow-sm sm:px-5">
                      Withdraw Now
                    </ButtonContact>
                    <div className="mt-1.5 flex items-center gap-2">
                      <HeadingPage size="xs" as="h3" className="tracking-[0.24px] !text-gray-700">
                        Minimum balance to withdrawal is ₹10
                      </HeadingPage>
                      <Img src="images/img_help_circle.svg" alt="help image" className="h-[14px] w-[14px]" />
                    </div>
                    <ButtonContact
                      rightIcon={
                        <Img src="images/img_pluscircle.svg" alt="plus-circle" className="h-[24px] w-[24px]" />
                      }
                      className="mt-[9px] flex h-[35px] w-full flex-row items-center justify-center gap-[11px] rounded-[17px] bg-green-900 px-[35px] text-center text-lg tracking-[0.36px] text-white-A700_01 sm:px-5 text-white-A700"
                      path="/bankdetails"
                    >
                      Edit Bank Account Details
                    </ButtonContact>
                    <ButtonContact
                      rightIcon={<FaArrowRight className="ml-2 text-white-A700" />}
                      className="mt-3.5 flex h-[35px] w-full flex-row items-center justify-center gap-[35px] rounded-[17px] bg-green-900 px-[35px] text-center text-lg tracking-[0.36px] text-white-A700_01 sm:px-5 text-white-A700"
                      path="/orders"
                    >
                      My Recent Orders
                    </ButtonContact>
                  </div>
                </div>
              </div>
            </div>

            {/* earnings recent orders section */}
            {/* {showRecentOrders && (
              <div className="flex w-[42%] flex-col items-start gap-8 rounded-[12px] bg-light_green-100 px-[27px] pb-[37px] pt-[22px] md:w-full sm:p-5">
                <HeadingPage size="md" as="h4" className="tracking-[0.60px]">
                  My Recent Orders
                </HeadingPage>
                <div className="flex flex-col items-start">
                  <HeadingPage as="h5" className="tracking-[0.40px] !text-gray-700">
                    Order ID
                  </HeadingPage>
                  <HeadingPage size="md" as="h6" className="mt-[5px] tracking-[0.60px]">
                    2144 5634 2341
                  </HeadingPage>
                  <HeadingPage as="h5" className="mt-1.5 tracking-[0.40px] !text-gray-700">
                    Order ID
                  </HeadingPage>
                  <HeadingPage size="md" as="h3" className="mt-[5px] tracking-[0.60px]">
                    2144 5634 2341
                  </HeadingPage>
                  <HeadingPage as="h5" className="mt-3 tracking-[0.40px] !text-gray-700">
                    Order ID
                  </HeadingPage>
                  <HeadingPage size="md" as="h3" className="mt-[5px] tracking-[0.60px]">
                    2144 5634 2341
                  </HeadingPage>
                </div>
              </div>
            )} */}
          </div>
        </div>
      </div>
    </>
  );
}
