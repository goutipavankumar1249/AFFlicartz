import { Helmet } from "react-helmet";
import { Img, Text, Heading, Button, Input, TextLog, ButtonLog } from "../../components";
import React from "react";
import { Link } from "react-router-dom";

export default function LogInPage() {
  return (
    <>
      <Helmet>
        <title>Login AfflicartZ - Earn Cashback on Every Purchase</title>
        <meta
          name="description"
          content="Join AfflicartZ today! Create your account to earn cashback on your favorite stores. Shop and save with every purchase. Sign up now and enjoy the benefits."
        />
      </Helmet>

      
      {/* signup page section */}
      <div className="flex w-full bg-light_green-300 min-h-screen overflow-x-hidden">
        {/* signup form section */}
        <div className="relative h-[1024px] md:min-h-screen w-[100%] md:h-[100vh]">
          {/* account creation section */}
          <div className="white_A700_99_white_A700_99_border absolute bottom-0 left-[65%] top-0  my-auto flex h-max flex-col items-center gap-[21px] rounded-[24px]  bg-gradient px-[17px] pb-3 pt-[17px] shadow-xs md:left-[20%]  md:w-[60%] sm:w-[80%] sm:left-10 sm:top-0">
            {/* header logo text section */}
            <div className="flex w-[71%] flex-col items-center md:w-full">
              <Img src="images/img_image_1.png" alt="header logo" className="h-[50px] w-[50px] object-contain" />
              <Heading size="s" as="h1" className="mt-[9px] !text-white-A700">
                Welcome Back
              </Heading>
              <Heading size="xs" as="h2" className="mt-[5px] w-full text-center leading-[18px]">
                Log in to your account
              </Heading>
            </div>

            {/* user input fields section */}
            <div className="flex flex-col self-stretch">
              <div className="mt-[5px] flex flex-col items-start">
                <Text as="p">Email</Text>
                <Input shape="round" name="Email Input" />
              </div>
              <div className="mt-[5px] flex flex-col items-start">
                <Text as="p">Password</Text>
                <Input shape="round" name="Password Input" />
              </div>


              {/* terms and signup button section */}
              <div className="mt-[13px] flex flex-col items-center">
                <ButtonLog
                  size="xs"
                  shape="round"
                  className="flex h-[35px] w-full flex-row items-center justify-center rounded-[17px] border border-solid border-white-A700_7f bg-white-A700 px-[117px] text-center text-lg font-bold text-green-900 sm:px-5"
                  path="/"
                >
                  Log In
                </ButtonLog>
                <Text size="s" as="p" className="mt-[13px]">
                  or Log in with
                </Text>

                {/* social media signup section */}
                <div className="flex gap-4">
                  <Button shape="circle" className="w-[36px] !rounded-[18px]" path="/">
                    <Img src="images/img_social_icons.svg" />
                  </Button>
                  <Button shape="circle" className="w-[36px] !rounded-[18px]" path="/otp">
                    <Img src="images/img_group_2.png" />
                  </Button>
                </div>
              </div>
            </div>

            {/* login redirect section */}
            <Text size="s" as="p">
              <span className="text-green-900">Don't have an account?&nbsp;</span>
              <Link to='/signup' className="inline">
                <span className="font-bold text-green-900">Sign Up</span>
              </Link>
            </Text>
          </div>
          <div className="absolute bottom-0 left-[0.00px] top-0 my-auto h-[100%] w-[50%] md:w-[100%] md:h-[40%] bg-light_green-200 md:right-0 md:my-0 sm:h-[20%] md:hidden" />
          <Img
            src="images/img_group_1.png"
            alt="footer image"
            className="absolute bottom-0 left-[0.00px] top-0 my-auto h-[100%] w-[50%] object-cover md:h-[50%] md:my-0 md:w-[100%] md:hidden"
          />

          {/* promotional graphics section */}
          <div className="absolute left-[2%] top-[7%] m-auto flex w-[66%] flex-col md:left-[40%] md:hidden">
            <Img
              src="images/img_image_1.png"
              alt="promo image"
              className="ml-28 h-[116px] w-[116px] object-cover md:ml-0 sm:h-[20%] sm:w-[20%] sm:mt-[-14%] md:hidden"
            />

            {/* brand highlight section */}
            <div className="relative mt-[-89px] flex flex-col items-center gap-[27px] md:gap-0 sm:text-sm sm:mt-[-15%] ">
              <Heading size="lg" as="h2" className="!font-inter !text-black-900 sm:text-sm">
                <span className="text-green-900">A</span>
                <span className="text-black-900">fflicart</span>
                <span className="text-green-900">Z</span>
              </Heading>

              {/* cashback offer section */}
              <div className="self-stretch pb-3.5 md:pt-[8%] md:pl-6">
                <div className="flex flex-col items-start gap-[39px]">
                  <div className="flex flex-col items-start gap-[3px]">
                    <Heading size="xl" as="h3" className="italic sm:text-sm">
                      Earn Cashback
                    </Heading>
                    <Heading as="h4" className="italic !text-gray-700 sm:text-sm">
                      on Every Purchase
                    </Heading>
                  </div>
                  <TextLog size="xl" as="p" className="ml-[-40px] mr-[10px] mt-[-10px] !font-sfprodisplay italic sm:text-sm">
                  <span className="font-shrikhand font-normal text-green-900">“</span>
                    <span className="text-green-900">Shop at your favorite stores and get money back!</span>
                    <span className="font-shrikhand font-normal text-green-900">“</span>
                  </TextLog>
                </div>
              </div>
            </div>
          </div>

          {/* decorative image left section */}
          {/* <Img
            src="images/img_image_removebg_preview.png"
            alt="background image"
            className="absolute bottom-[10%] left-[0.00px] m-auto h-[514px] w-[43%] object-cover"
          /> */}

          {/* decorative image right section */}
          <Img
            src="images/img_image_removebg_preview_514x530.png"
            alt="overlay image"
            //absolute bottom-[13%] left-[0.00px] m-auto h-[514px] w-[42%] object-cover
            className="absolute bottom-[13%] left-[0.00px] m-auto h-[514px] w-[42%] object-cover md:my-0 md:top-[7%] md:h-[350px] md:w-[40%] sm:h-[100px] sm:w-[25%] md:hidden "
          />
        </div>
      </div>
    </>
  );
}
