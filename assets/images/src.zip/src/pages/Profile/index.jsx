import { Helmet } from "react-helmet";
import { useState } from "react";
import { HeadingPage, Img, ButtonContact } from "../../components";
import HeaderHome from "components/HeaderHome";
import React from "react";
import { Link } from "react-router-dom";
import { IoIosArrowUp, IoIosArrowDown } from "react-icons/io";

export default function ProfilePage() {
  const [showBankDetails, setShowBankDetails] = useState(false);
  const [gender,setGender]=useState('female');

  return (
    <>
      <Helmet>
        <title>User Profile - Manage Your AfflicartZ Account Details</title>
        <meta
          name="description"
          content="Access and edit your profile information, including email, mobile number, and bank details on your AfflicartZ Profile Page."
        />
      </Helmet>

      {/* profile main section */}
      <div className="w-full  bg-light_green-300 ">
        {/* profile content section */}
        <div className="relative min-h-screen">
          {/* profile banner section */}
          <div className={`absolute top-[0.00px] left-0 right-0 m-auto ${showBankDetails?"h-[122vh]":"h-[100vh]"} min-h-screen w-full bg-light_green-200`} />

          {/* profile navigation section */}
          <div className="absolute bottom-0 left-[0.00px] top-0 my-auto flex w-[82%] items-center justify-end bg-[url(/public/images/img_group_5.png)] bg-cover bg-no-repeat pb-[341px] pl-14 pr-[241px] pt-[270px]">
            
          </div>
            <div className="absolute flex z-10 top-0 md:top-9 items-center ml-[40%] gap-4 sm:ml-16 md:ml-[30%] sm:top-8">
              <Img
                src="images/img_image_1.png"
                alt="primary image"
                className="h-[116px] w-[116px] md:h-[88px] md:w-[88px] object-fit"
              />
              <HeadingPage size="xl" as="h1" className="!font-inter !text-black-900">
                <span className="text-green-900">A</span>
                <span className="text-black-900">fflicart</span>
                <span className="text-green-900">Z</span>
              </HeadingPage>
            </div>
          {/* profile spacer section */}
          <div
            className="absolute bottom-0 left-0 right-0 top-0 mt-28 mx-auto  h-[440px] w-[46%] rounded-[12px] shadow-sm sm:w-[80%] md:w-[60%] md:h-[420px] "
            style={{
              boxShadow: "0px 16px 32px 0px rgba(0, 0, 0, 1), -16px -16px 32px 0px rgba(186, 221, 158, 1)",
              background: "rgba(215, 231, 200, 1)",
            }}
          />

          {/* profile summary section */}
          <div className="absolute bottom-0 left-0 right-0 mt-28 top-0 m-auto h-[440px] w-[46%] rounded-[12px] shadow-sm sm:w-[80%] md:w-[60%] flex">
            <div
              className="relative z-[1] mt-[17px] flex flex-1 flex-col items-start pl-[2%] "

            >
              <HeadingPage size="md" as="h2" className="tracking-[0.60px] !text-gray-700">
                Hello,
              </HeadingPage>
              <HeadingPage size="lg" as="h3" className="tracking-[0.80px]">
                Surya
              </HeadingPage>
              <div className="mt-[11px] flex flex-col items-start">
                <HeadingPage as="h4" className="tracking-[0.40px] !text-gray-700">
                  Email ID
                </HeadingPage>
                <HeadingPage size="md" as="h5" className="tracking-[0.60px]">
                  suryaraj@gmail.com
                </HeadingPage>
                <HeadingPage as="h6" className="mt-2.5 tracking-[0.40px] !text-gray-700">
                  Mobile Number
                </HeadingPage>
                <HeadingPage size="md" as="h3" className="tracking-[0.60px]">
                  +91 8899776655
                </HeadingPage>
              </div>
              <div className="mt-[33px] flex flex-col gap-3 self-stretch">
                <Link to={"/profile"}>
                  <ButtonContact
                    rightIcon={<Img src="images/img_edit.svg" alt="edit" className="h-[19px] w-[19px]" />}
                    className="flex h-[38px] w-full flex-row items-center justify-center gap-[34px] rounded-[19px] bg-green-900 px-[35px] text-center text-xl tracking-[0.40px] text-white-A700 sm:px-5 md:text-lg sm:text-sm"
                  >
                    Edit Profile
                  </ButtonContact>
                </Link>
                <ButtonContact
                  rightIcon={showBankDetails ? <IoIosArrowUp className="h-[26px] w-[26px]" /> : <IoIosArrowDown className="h-[26px] w-[26px]" />}
                  className="flex h-[38px] w-full flex-row items-center justify-center gap-6 rounded-[19px] bg-green-900 px-[35px] text-center text-xl tracking-[0.40px] text-white-A700 sm:px-5 md:text-lg sm:text-sm"
                  onClick={() => setShowBankDetails(!showBankDetails)}
                >
                  Bank Details
                </ButtonContact>
                {showBankDetails && (
            <div
              className="flex  flex-col items-start rounded-[12px] px-[34px] pb-8 pt-[22px] "
              style={{
                background: "rgba(215, 231, 200, 1)",
              }}
            >
              <HeadingPage size="md" as="h2" className="tracking-[0.60px]">
                Bank Details
              </HeadingPage>
              <HeadingPage as="h3" className="mt-[11px] tracking-[0.40px] !text-gray-700">
                Account Number
              </HeadingPage>
              <HeadingPage size="md" as="h4" className="mt-[5px] tracking-[0.60px]">
                2144 5634 2341
              </HeadingPage>
              <HeadingPage as="h5" className="mt-[11px] tracking-[0.40px] !text-gray-700">
                IFS Code
              </HeadingPage>
              <HeadingPage size="md" as="h6" className="mt-[5px] tracking-[0.60px]">
                SBIN0012311
              </HeadingPage>
            </div>
          )}
              </div>
            </div>
            
            {gender=='male'&&<Img
              src="images/img_character.svg"
              alt="character image"
              className="relative ml-[-25px] h-[482px] w-[301px] md:ml-0 md:h-[350px] md:w-[30%] sm:h-[380px] sm:w-[35%]"
            />}
            {
              gender=='female'&&<Img
              src="images/img_female_character.svg"
              alt="character image"
              className="relative ml-[-50px] h-[482px] w-[301px] md:ml-0 md:h-[350px] md:w-[30%] sm:h-[380px] sm:w-[35%]"
            />
            }
          </div>

          {/* profile bank details section */}
          
        </div>
      </div>
    </>
  );
}
